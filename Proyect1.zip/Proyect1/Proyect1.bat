@echo off
title Proyect1 Matrix Core Setup
mode con: cols=80 lines=15
color 0a

echo.
echo  ======================================================================
echo   INICIALIZANDO SUBSISTEMA DE RED... POR FAVOR ESPERE
echo  ======================================================================
echo.

:: Simulación de la barra de carga animada
set "bar="
for /l %%i in (1,1,20) do (
    set "bar=!bar!█"
    cls
    echo.
    echo  ======================================================================
    echo   INICIALIZANDO SUBSISTEMA DE RED... POR FAVOR ESPERE
    echo  ======================================================================
    echo.
    echo   Cargando modulos del nucleo...
    echo.
    echo   [%%i/20] [!bar!]
    echo.
    :: Pequeña pausa en milisegundos para que se vea fluida la carga
    powershell -NoProfile -Command "Start-Sleep -Milliseconds 150"
)

cls
echo.
echo  ======================================================================
echo   PROCESO COMPLETADO
echo  ======================================================================
echo.
echo  C:\Users\System\Setup^> hacking system completed
echo.
pause
exit
