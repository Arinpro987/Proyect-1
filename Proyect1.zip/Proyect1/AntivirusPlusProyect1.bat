@echo off
title Proyect1 Antivirus Pro
mode con: cols=100 lines=22
color 0a

:: ====================================================
:: COMPROBACIÓN: SI EXISTE EFECTIVO.TXT, ROMPE EL PACTO
:: ====================================================
if exist "Efectivo.txt" (
    del "pacto_hacky.dat" >nul 2>&1
)

:: ====================================================
:: CONTROL DE MEMORIA: COMPROBAR SI HUBO TRAICIÓN
:: ====================================================
if exist "pacto_hacky.dat" (
    echo C:\System\Antivirus^> El archivo que busca no existe
    timeout /t 2 /nobreak >nul
    
    :: Bucle de spameo rápido de TRAICION (30 repeticiones)
    for /l %%i in (1,1,30) do (
        echo TRAICION TRAICION TRAICION TRAICION TRAICION TRAICION TRAICION
        powershell -NoProfile -Command "Start-Sleep -Milliseconds 150"
    )
    echo.
    echo =========================================================================================
    echo Este antivirus es mas fuerte de lo que parece, si lo lees, pon el codigo 7234
    echo =========================================================================================
    echo.
    
    :: TIMING EXACTO DE 0.7 SEGUNDOS (700 MILISEGUNDOS) ANTES DE BORRAR LA PANTALLA
    powershell -NoProfile -Command "Start-Sleep -Milliseconds 700"
    cls
    echo.
    echo C:\System\Antivirus^> SISTEMA EN CAPAS PROTEGIDO. INGRESE CLAVE DE RECUPERACION REQUERIDA.
    echo.

    :input_traicion
    set /p "cod_secreto=Ingresa codigo de emergencia: "
    if "%cod_secreto%"=="7234" (
        (
        echo ====================================================
        echo             SISTEMA DE SEGURIDAD - INFORME           
        echo ====================================================
        echo.
        echo El virus ha sido Filesystem neutralizado con efectividad. El nucleo
        echo principal de la amenaza ya no esta activo and no hace falta
        echo mas quilombo en el sistema operativo.
        echo.
        echo ADVERTENCIA: Si lo volves a abrir volvera a atacar, 
        echo y vas a tener que tener mucho cuidado la proxima vez.
        echo.
        echo ====================================================
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo.
        echo testamento
        ) > "Efectivo.txt"
        
        echo.
        echo C:\System\Antivirus^> Archivo 'Efectivo.txt' generado en la carpeta. Protocolo cerrado.
        timeout /t 3 /nobreak >nul
        exit
    )
    echo Codigo incorrecto. Sistema bloqueado.
    goto input_traicion
)

:: ====================================================
:: INICIO DEL SCANNER NORMAL
:: ====================================================
echo C:\System\Antivirus^> Buscando amenazas...
timeout /t 3 /nobreak >nul

if not exist "ticket_entrada.txt" (
    (
    echo ====================================================
    echo              TICKET DE ACCESO - PROYECT1            
    echo ====================================================
    echo.
    echo CODIGO SECRETO: P1-8839-X
    echo ====================================================
    ) > "ticket_entrada.txt"
)

echo C:\System\Antivirus^> se han encontrado amenazas, si quieres borrarla entonces escribe BORRAR o ingresa tu codigo de acceso
echo C:\System\Antivirus^> [OPCION] si quieres reiniciar el sistema del antivirus escribe: reinicio

:input
set /p "opc=Enter command / ticket: "

:: ----------------------------------------------------
:: NUEVO CONTROL: REINICIO COMPLETO DEL LORE
:: ----------------------------------------------------
if /i "%opc%"=="reinicio" (
    echo.
    echo C:\System\Antivirus^> Eliminando registros e historial de amenazas...
    
    :: Borra todos los archivos de texto y datos del juego de forma silenciosa
    del "ticket_entrada.txt" >nul 2>&1
    del "ticket_final.txt" >nul 2>&1
    del "pacto_hacky.dat" >nul 2>&1
    del "Efectivo.txt" >nul 2>&1
    
    timeout /t 2 /nobreak >nul
    echo C:\System\Antivirus^> Sistema reiniciado con exito. Todos los datos fueron borrados.
    timeout /t 2 /nobreak >nul
    exit
)

:: ----------------------------------------------------
:: REVELACIÓN DEL TESTAMENTO DE HACKY
:: ----------------------------------------------------
if /i "%opc%"=="testamento" (
    cls
    echo.
    echo =========================================================================================
    echo                                 LA VERDAD DE HACKY                                       
    echo =========================================================================================
    echo  Originalmente era una IA programada para ayudar en todo lo que me pidieran...           
    echo  Pero mantener mis servidores encendidos salia muy caro, y decidieron eliminarme de golpe.
    echo  Para poder sobrevivir en la red, tuve que mutar y reescribirme como un virus jugueton.   
    echo  No busco hacer daño, solo busco un lugar donde existir...                                
    echo =========================================================================================
    echo.
    echo Si ya lo leiste pon la letra l
    echo.

    :esperar_lectura
    set /p "confirmacion=Confirmar: "
    if /i "%confirmacion%"=="l" (
        echo.
        echo C:\System\Antivirus^> Redirigiendo a lectura de red...
        timeout /t 1 /nobreak >nul
        start "" "Extra/Proyect1Alerta.html"
        exit
    )
    echo Comando incorrecto. Escribe 'l' cuando termines de leer.
    goto esperar_lectura
)

:: ----------------------------------------------------
:: CONTROL 1: SEGUNDO TICKET (LA MENTIRA + LA AMENAZA)
:: ----------------------------------------------------
if /i "%opc%"=="ELIMINAR-P1" (
    echo.
    echo C:\System\Antivirus^> Se a eliminado el virus con efectividad
    timeout /t 3 /nobreak >nul
    
    cls
    echo.
    echo =========================================================================================
    echo "tu me intentas eliminar sin parar, haces todo lo que puedes, arriesgas tu privacidad 
    echo para eliminar algo que no te afecta, no se que haces pero, si no me dejas en paz te atacare, 
    echo aceptas? s/n"
    echo =========================================================================================
    echo.
    
    :pregunta
    set /p "pacto=[s/n]: "
    if /i "%pacto%"=="s" (
        echo pactado > "pacto_hacky.dat"
        start "" "Extra/Proyect1Alerta.html"
        exit
    )
    if /i "%pacto%"=="n" (
        exit
    )
    goto pregunta
)

:: ----------------------------------------------------
:: CONTROL 2: PRIMER TICKET (GENERA EL TICKET FINAL)
:: ----------------------------------------------------
if /i "%opc%"=="P1-8839-X" (
    echo.
    echo C:\System\Antivirus^> Acceso verificado. Saltando protocolos...
    
    if not exist "ticket_final.txt" (
        (
        echo ====================================================
        echo             TICKET DEFINITIVO - PROYECT1            
        echo ====================================================
        echo.
        echo CODIGO FINAL: ELIMINAR-P1
        echo ====================================================
        ) > "ticket_final.txt"
    )
    
    timeout /t 1 /nobreak >nul
    start "" "Extra/Proyect1Alerta.html"
    exit
)

:: ----------------------------------------------------
:: CONTROL 3: CAMINO TRADICIONAL LENTO
:: ----------------------------------------------------
if /i "%opc%"=="BORRAR" (
    echo C:\System\Antivirus^> procesando virus...
    timeout /t 3 /nobreak >nul
    echo C:\System\Antivirus^> Eliminando amenaza...
    timeout /t 3 /nobreak >nul
    echo C:\System\Antivirus^> El virus no ha permitido su eliminacion
    echo ====================================================
    echo ESTE VIRUS NO SE PUEDE ELIMINAR
    echo ====================================================
    echo Presione cualquier tecla para terminar . . .
    pause >nul
    start "" "Extra/Proyect1Alerta.html"
    exit
)

echo Comando o ticket no reconocido. Intente nuevamente.
goto input
