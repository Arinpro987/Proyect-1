@echo off
:: TRUCO: Fuerza a esta consola a ocultarse al 100% en segundo plano sin mostrar ventana achicada
if not "%1"=="oculto" (
    powershell -NoProfile -Command "Start-Process -FilePath '%0' -ArgumentList 'oculto' -WindowStyle Hidden"
    exit /b
)

:: --- NOTIFICACIÓN 1 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Error; $n.BalloonTipIcon = 'Error'; $n.BalloonTipTitle = 'WINDOWS COMPROMETIDO'; $n.BalloonTipText = 'windows a dejado de responder correctamente'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 3 /nobreak >nul

:: --- NOTIFICACIÓN 2 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Warning; $n.BalloonTipIcon = 'Warning'; $n.BalloonTipTitle = 'WINDOWS DEFENDER'; $n.BalloonTipText = 'windows defender a dejado de responder'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 3 /nobreak >nul

:: --- NOTIFICACIÓN 3 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Information; $n.BalloonTipIcon = 'Info'; $n.BalloonTipTitle = 'HACKY'; $n.BalloonTipText = 'no podras matarme'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 3 /nobreak >nul

:: --- NOTIFICACIÓN 4 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Error; $n.BalloonTipIcon = 'Error'; $n.BalloonTipTitle = 'Leer rapidamente'; $n.BalloonTipText = 'EL QUE LO LEE ES GAY JAJJAJ'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 6 /nobreak >nul

:: --- NOTIFICACIÓN 5 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Error; $n.BalloonTipIcon = 'Error'; $n.BalloonTipTitle = 'HACKY'; $n.BalloonTipText = 'enserio, leiste el mensaje anterior y te la creiste, jaja que tonto que eres'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 3 /nobreak >nul

:: --- NOTIFICACIÓN 6 ---
powershell -NoProfile -Command "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); $n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Error; $n.BalloonTipIcon = 'Error'; $n.BalloonTipTitle = 'Explorador de archivos'; $n.BalloonTipText = 'System32 ha sido eliminado sin permiso del usuario'; $n.Visible = $true; $n.ShowBalloonTip(5000);"
timeout /t 3 /nobreak >nul

:: Cierra el proceso de fondo limpiamente para indicarle al /wait que ya terminó
exit
