@echo off
title Windows Operating System Emergency Recovery
color 00

:: Fuerza la pantalla completa absoluta ocultando la barra de tareas y el escritorio
powershell -NoProfile -Command "(Get-Process -Id $PID).MainWindowHandle | foreach { Add-Type -TypeDefinition '[DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);'; [void]ShowWindow($_, 3) }"
powershell -NoProfile -Command "$wshell = New-Object -ComObject Wscript.Shell; $wshell.SendKeys('{F11}')"

:: Cambia el color al azul oficial de la pantalla de la muerte de Windows 10/11
color 1f
setlocal enabledelayedexpansion
cls

:: Bucle de porcentaje de 3% en 3% hasta 100%
for /l %%i in (0,3,102) do (
    set "pct=%%i"
    if !pct! gtr 100 set "pct=100"
    
    if !pct! leq 15 set "archivo=C:\Windows\System32\drivers\hal.dll"
    if !pct! gtr 15 if !pct! leq 30 set "archivo=C:\Windows\System32\ntoskrnl.exe"
    if !pct! gtr 30 if !pct! leq 45 set "archivo=C:\Windows\System32\drivers\win32k.sys"
    if !pct! gtr 45 if !pct! leq 60 set "archivo=C:\Windows\System32\vga.dll"
    if !pct! gtr 60 if !pct! leq 75 set "archivo=C:\Windows\System32\config\SYSTEM"
    if !pct! gtr 75 if !pct! leq 90 set "archivo=C:\Windows\System32\drivers\ndis.sys"
    if !pct! gtr 90 set "archivo=C:\Windows\System32\bootres.dll"

    cls
    echo.
    echo.
    echo.
    echo.
    
    :: EMOJI GIGANTE MINIMALISTA DE COSTADO
    echo                     ^|  ^|          /
    echo                     ^|  ^|         /
    echo                                 /
    echo                     ^|  ^|        ^|
    echo                     ^|  ^|        ^|
    echo                                 \
    echo                                  \
    echo                                   \
    echo.
    echo                     Se ha producido un problema en su equipo y necesita reiniciarse.
    echo                     Vamos a recopilar informacion sobre el error y, despues, se reiniciara automaticamente.
    echo.
    echo                     Si llama a un proveedor de soporte tecnico, dificultele esta informacion:
    echo                     Codigo de detencion: CRITICAL_PROCESS_DIED
    echo                     Lo que fallo: win32kfull.sys
    echo.
    echo                     Para obtener mas informacion sobre este problema y las posibles soluciones, visite:
    echo                     https://windows.com
    echo.
    echo                     ===================================================================================================
    echo.
    echo                     Porcentaje completado: !pct!%%
    echo.
    echo                     Restaurando: !archivo!
    echo.
    
    powershell -NoProfile -Command "Start-Sleep -Milliseconds 200"
    if !pct! equ 100 goto fin_carga
)

:fin_carga
cls
color 07
mode con: cols=85 lines=20
echo.
echo  C:\Windows\System32^> Reconstruccion de sectores NTFS completada.
echo  C:\Windows\System32^> Los archivos corruptos de System32 han sido restaurados con exito.
echo.

:: ====================================================================
:: CONTROL DEL FLUJO CON MÍNIMIZACIÓN CORREGIDA E INFALIBLE
:: ====================================================================
if exist "%temp%\primer_pase.dat" (
    del "%temp%\primer_pase.dat" >nul 2>&1
    echo  C:\Windows\System32^> El sistema se ha reiniciado correctamente de forma definitiva.
    timeout /t 3 /nobreak >nul
    exit
) else (
    echo listo > "%temp%\primer_pase.dat"
    echo  C:\Windows\System32^> Levantando servicio de notificaciones secundario...
    timeout /t 2 /nobreak >nul
    
    :: NUEVO TRUCO INFALIBLE: Minimiza la consola usando un comando de shell nativo sin types externos
    powershell -NoProfile -Command "$w = New-Object -ComObject Shell.Application; $w.MinimizeAll()"
    
    :: Congela el proceso esperando a que terminen las alertas invisibles de fondo
    start /wait "" "alertas_sistema.bat"
    
    :: Una vez cerradas las alertas, restaura las ventanas y levanta el segundo pase
    powershell -NoProfile -Command "$w = New-Object -ComObject Shell.Application; $w.UndoMinimizeAll()"
    start "" "Reinicio.bat"
    exit
)
